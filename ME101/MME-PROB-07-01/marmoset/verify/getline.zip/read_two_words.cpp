/*
read_two_words.cpp

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>
#include <fstream>

using namespace std;

int main()
{
  ifstream file_in("two_words.txt");
  string input_string;

  getline(file_in, input_string);

  cout << input_string << endl;

  file_in.close();
  return 0;
}
