#include <iostream>
#include <fstream>

using namespace std;

int main()
{
  ifstream file_in("two_words.txt");
  string words;

  file_in >> words;

  cout << words << endl;

  file_in.close();
  return 0;
}
