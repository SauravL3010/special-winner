/*
bigger_or_smaller.cpp

Error case: Does not print the keyword 'larger'.

2018-03-10 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
    int num1 = 0, num2 = 0;

    cout << "Enter two integers: ";
    cin >> num1 >> num2;

    cout << "first second larger equal" << endl;

    return 0;
}
