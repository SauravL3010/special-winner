/*
bigger_or_smaller.cpp

Error case: Does not print the keyword 'larger'.

2018-03-10 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
    int num1 = 0, num2 = 0;

    cout << "Enter two integers: ";
    cin >> num1 >> num2;

    if (num1 > num2)
        cout << "The first number." << endl;
    else if (num2 > num1)
        cout << "The second number." << endl;
    else
        cout << "The two numbers are equal." << endl;

    return 0;
}
