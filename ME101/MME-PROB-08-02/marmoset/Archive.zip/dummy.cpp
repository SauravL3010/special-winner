/*
dummy.cpp

2017-02-22 - created by David Lau

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
  cout << "This program is to enable the placeholder Makefile." << endl;

  return 0;
}
