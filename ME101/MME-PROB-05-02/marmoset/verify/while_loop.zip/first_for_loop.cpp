/*
first_for_loop.cpp

2018-02-22 - created

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    int loop_limit = 0;

    cout << "Enter a positive integer: ";
    cin >> loop_limit;

    // error - uses while loop when problem specifies for loop
    int print_number = 1;
    while (print_number <= loop_limit)
    {
        cout << print_number << endl;
        print_number++;
    }

    return EXIT_SUCCESS;
}
