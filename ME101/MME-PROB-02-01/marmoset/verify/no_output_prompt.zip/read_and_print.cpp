/*
read_and_print.cpp
* no output prompt

2018-02-08 - created

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
  float input_integer = 0;

  cout << "Enter an integer to store: ";
  cin >> input_integer;
  cout << endl;

  // cout << "The number entered was: ";
  cout << input_integer << endl;

  return 0;
}
