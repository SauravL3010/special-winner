/*
read_and_print.cpp

2017-03-12 - created

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
  float input_integer = 0;

  cout << "Enter an integer to store: ";
  cin >> input_integer;
  cout << endl;

  cout << "The number entered was: ";
  cout << input_integer << endl;

  return 0;
}
