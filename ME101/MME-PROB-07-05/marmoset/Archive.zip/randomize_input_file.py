import random

def randomize_input_file() :
    sorted_file = open("medal_count_2018.txt", "r")
    randomized_file = open("medal_count.txt", "w+")

    input_data = sorted_file.readlines()

    while len(input_data) > 0 :
        pick_position = random.randint(0, len(input_data) - 1)
        randomized_file.write(input_data[pick_position])
        input_data.pop(pick_position)

    randomized_file.close()
