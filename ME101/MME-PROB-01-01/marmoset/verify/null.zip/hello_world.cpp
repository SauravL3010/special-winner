/*
hello_world.cpp
© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
  // cout << "Hello World" << endl;
  return 0;
}
