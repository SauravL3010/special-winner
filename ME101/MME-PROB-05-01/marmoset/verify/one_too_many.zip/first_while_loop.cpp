/*
first_while_loop.cpp

error test case: null program

2018-02-12 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

int main()
{
    for (int count = 1; count <= 26; count++)
        cout << count << endl;

    return 0;
}
