/*
first_while_loop.cpp

error test case: null program

2018-02-12 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

int main()
{
    return 0;
}
