/*
first_while_loop.cpp

error test case: uses a do-while loop instead of a while loop

2018-02-12 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    int count = 0;
    do {
        count++;
        cout << count << endl;
    } while (count < 25);

    return EXIT_SUCCESS;
}
