/*
first_while_loop.cpp

error test case: uses a for loop instead of a while loop

2018-02-12 - created

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    for (int count = 1; count <= 25; count++)
    {
        cout << count << endl;
    }

    return EXIT_SUCCESS;
}
