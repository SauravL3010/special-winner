#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
test_run_python_01.py
© 2019 DAVID LAU ALL RIGHTS RESERVED
'''

print("This is a test - 01.")
exit(0)
