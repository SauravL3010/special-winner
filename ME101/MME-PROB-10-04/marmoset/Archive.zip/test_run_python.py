#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
test_run_python.py
© 2019 DAVID LAU ALL RIGHTS RESERVED
'''

import os

os.system("make")
print("This is a test.")
exit(0)
