// binary_conversion.cpp
// 2018-09-18 - created
// © 2018 DAVID LAU ALL RIGHTS RESERVED

#include <iostream>

int main()
{
    int decimal_number{0};
    bool binary_digits[64]{0};

    std::cout << "Please enter a decimal number to convert to binary: ";
    std::cin >> decimal_number;

    int digit_index = 0;
    while (decimal_number > 0)
    {
        binary_digits[digit_index] = decimal_number % 2;
        decimal_number = decimal_number / 2;
        digit_index++;
    }

    std::cout << "The number in binary form is: ";
    do
    {
        digit_index--;
        std::cout << binary_digits[digit_index];
    } while (digit_index > 0);
    std::cout << std::endl;

    return 0;
}
