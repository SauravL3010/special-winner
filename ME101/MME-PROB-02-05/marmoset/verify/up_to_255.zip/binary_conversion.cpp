// upside-down-pyramid.cpp
// 2018-09-16 - created
// © 2017 DAVID LAU ALL RIGHTS RESERVED

#include <iostream>

int main()
{
    int decimal_number{0};

    std::cout << "Please enter a number between 0 and 255 to convert to binary: ";
    std::cin >> decimal_number;

    std::cout << "The number in binary form is: ";
    std::cout << decimal_number / 128;
    decimal_number = decimal_number % 128;
    std::cout << decimal_number / 64;
    decimal_number = decimal_number % 64;
    std::cout << decimal_number / 32;
    decimal_number = decimal_number % 32;
    std::cout << decimal_number / 16;
    decimal_number = decimal_number % 16;
    std::cout << decimal_number / 8;
    decimal_number = decimal_number % 8;
    std::cout << decimal_number / 4;
    decimal_number = decimal_number % 4;
    std::cout << decimal_number / 2;
    decimal_number = decimal_number % 2;
    std::cout << decimal_number << std::endl;

    return 0;
}
