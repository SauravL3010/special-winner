// binary_conversion.cpp
// ERROR TEST CASE - uses if statements
// 2018-09-18 - created
// © 2018 DAVID LAU ALL RIGHTS RESERVED

#include <iostream>

int main()
{
    int decimal_number{0};

    std::cout << "Please enter a decimal number to convert to binary: ";
    std::cin >> decimal_number;

    if (decimal_number >= 128)
    {
        std::cout << "1";
        decimal_number = decimal_number - 128;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 64)
    {
        std::cout << "1";
        decimal_number = decimal_number - 64;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 32)
    {
        std::cout << "1";
        decimal_number = decimal_number - 32;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 16)
    {
        std::cout << "1";
        decimal_number = decimal_number - 16;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 8)
    {
        std::cout << "1";
        decimal_number = decimal_number - 8;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 4)
    {
        std::cout << "1";
        decimal_number = decimal_number - 4;
    }
    else
    {
        std::cout << "0";
    }
    if (decimal_number >= 2)
    {
        std::cout << "1";
        decimal_number = decimal_number - 2;
    }
    else
    {
        std::cout << "0";
    }
    std::cout << decimal_number << std::endl;

    return 0;
}
