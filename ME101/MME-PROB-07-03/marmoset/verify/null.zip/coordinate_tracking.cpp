/*
coordinate_tracking.cpp

2018-02-22 - created

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

int main()
{
    // error - null program
    
    return EXIT_SUCCESS;
}
