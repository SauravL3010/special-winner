/*
2D_print.cpp

2018-04-04 - created

ERROR CASE - hard-coded output

© 2018 DAVID LAU ALL RIGHTS RESERVED
*/

#include <iostream>

using namespace std;

const int A1_ROWS = 3;
const int A1_COLS = 2;

const int A2_ROWS = 5;
const int A2_COLS = 7;

const int A3_ROWS = 3;
const int A3_COLS = 3;

int main()
{
    int array_1[A1_ROWS][A1_COLS] =
    {   {5, 3},
        {2, 2},
        {1, 7}};

    double array_2[A2_ROWS][A2_COLS] =
    {   {3.2, -1.7, 3.6, 1.2, -0.6, 8.0, -7.7},
        {-0.8, 1.1, 2.3, 2.3, -4.8, 8.0, -1.2},
        {1.2, 3.3, 6.8, -2.1, 0.0, 2.3, -8.0},
        {4.2, 5.7, 3.3, -9.0, -8.0, -3.3, 2.2},
        {0.9, 5.7, 3.2, -8.9, 8.0, -8.0, -7.7}};

    string array_3[A3_ROWS][A3_COLS] =
    {   {"Mike", "Carol", "Ryan"},
        {"David", "Fiona", "Chris"},
        {"Pete", "June", "Don"}};

    cout << "    5    3" << endl;
    cout << "    2    2" << endl;
    cout << "    1    7" << endl;
    cout << endl;
    cout << "    3.2   -1.7    3.6    1.2   -0.6      8   -7.7" << endl;
    cout << "   -0.8    1.1    2.3    2.3   -4.8      8   -1.2" << endl;
    cout << "    1.2    3.3    6.8   -2.1      0    2.3     -8" << endl;
    cout << "    4.2    5.7    3.3     -9     -8   -3.3    2.2" << endl;
    cout << "    0.9    5.7    3.2   -8.9      8     -8   -7.7" << endl;
    cout << endl;
    cout << "   Mike  Carol   Ryan" << endl;
    cout << "  David  Fiona  Chris" << endl;
    cout << "   Pete   June    Don" << endl;

    return 0;
}
