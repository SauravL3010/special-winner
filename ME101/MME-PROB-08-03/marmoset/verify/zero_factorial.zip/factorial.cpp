/*
factorial.cpp

2017-02-22 - intentional bug - does not calculate 0! correctly

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

long long factorial(const int n)
{
  long long result = n;

  for (int term = n-1; term > 1; term--)
    result = result * term;

  return result;
}
