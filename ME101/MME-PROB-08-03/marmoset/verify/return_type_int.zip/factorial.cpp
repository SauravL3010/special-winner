/*
factorial.cpp

2017-02-23 - intentional bug: returns an int when it should return a long long.
              This limits its range and therefore will not correctly calculate
              20!, for example.

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

int factorial(const int n)
{
  int result = 1;

  for (int term = 2; term <= n; term++)
    result = result * term;

  return result;
}
