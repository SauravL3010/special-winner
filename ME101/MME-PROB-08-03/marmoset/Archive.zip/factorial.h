/*
factorial_main.h

2017-02-22 - created

© 2017 DAVID LAU ALL RIGHTS RESERVED
*/

long long factorial(const int n);
